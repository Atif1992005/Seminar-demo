﻿<?php
include 'config.php';
session_destroy();
redirect('index.php');
?>
